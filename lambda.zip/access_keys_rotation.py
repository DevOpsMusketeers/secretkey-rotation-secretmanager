import json
import boto3
from botocore.exceptions import ClientError
import base64

def lambda_handler(event, context):
    secret_name = event['SecretId'].split(':')[-1][:-7]
    region_name = event['SecretId'].split(':')[3]
    session = boto3.session.Session(region_name=region_name)
    secret_manager = session.client("secretsmanager")

    print(secret_name)

    try:
        get_secret_value_response = secret_manager.get_secret_value(
            SecretId=secret_name
        )

    except ClientError as e:
        if e.response["Error"]["Code"] == "DecryptionFailureException":
            raise e
        elif e.response["Error"]["Code"] == "InternalServiceErrorException":
            raise e
        elif e.response["Error"]["Code"] == "InvalidParameterException":
            raise e
        elif e.response["Error"]["Code"] == "InvalidRequestException":
            raise e
        elif e.response["Error"]["Code"] == "ResourceNotFoundException":
            raise e
    else:
        if "SecretString" in get_secret_value_response:
            secret = get_secret_value_response["SecretString"]
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response["SecretBinary"])
    
    secrets = json.loads(get_secret_value_response["SecretString"])
    access_key,secret_key = update_access_keys(session,secrets['ACCESS_KEY_ID'])

    update_secret(secret_manager,secret_name,secrets,ACCESS_KEY_ID=access_key,SECRET_ACCESS_KEY_ID=secret_key)

    return {
        'statusCode': 200,
        'body': json.dumps('Updated keys')
    }

def update_secret(secret_manager,secret_name,secrets,**kwargs):
    for i,j in kwargs.items():
        secrets[i] = j
    secret_dict_to_json = dict(list(secrets.items()))
    
    upd_sec = secret_manager.put_secret_value(SecretId=secret_name,SecretString=json.dumps(secret_dict_to_json))
    return "Updated the secrets with Keys: {}".format(kwargs.keys())

def update_access_keys(session,access_key):
    iam = session.client("iam")

    user_name = iam.get_access_key_last_used(
    AccessKeyId=access_key
    )
    print(user_name['UserName'])
    keys = iam.list_access_keys(
        UserName=user_name['UserName']
    )
    if len(keys['AccessKeyMetadata']) == 2:
        if (keys['AccessKeyMetadata'][1]['CreateDate'] - keys['AccessKeyMetadata'][0]['CreateDate']).days < 0:
            iam.delete_access_key(AccessKeyId=keys['AccessKeyMetadata'][1]['AccessKeyId'],UserName=user_name['UserName'])
            new_access_key = iam.create_access_key(UserName=user_name['UserName'])
        else:
            iam.delete_access_key(AccessKeyId=keys['AccessKeyMetadata'][0]['AccessKeyId'],UserName=user_name['UserName'])
            new_access_key = iam.create_access_key(UserName=user_name['UserName'])
    else:
        new_access_key = iam.create_access_key(UserName=user_name['UserName'])

    return new_access_key['AccessKey']['AccessKeyId'],new_access_key['AccessKey']['SecretAccessKey']